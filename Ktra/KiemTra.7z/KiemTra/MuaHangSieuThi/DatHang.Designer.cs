﻿namespace MuaHangSieuThi
{
    partial class DatHang
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.textBoxTenKH = new System.Windows.Forms.TextBox();
            this.textBoxSDT = new System.Windows.Forms.TextBox();
            this.buttonChoVaoGio = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.buttonMuaHang = new System.Windows.Forms.Button();
            this.numericUpDownSoLuong = new System.Windows.Forms.NumericUpDown();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.checkBoxChuoi = new System.Windows.Forms.CheckBox();
            this.checkBoxHong = new System.Windows.Forms.CheckBox();
            this.checkBoxBuoi = new System.Windows.Forms.CheckBox();
            this.checkBoxLe = new System.Windows.Forms.CheckBox();
            this.checkBoxNho = new System.Windows.Forms.CheckBox();
            this.checkBoxCam = new System.Windows.Forms.CheckBox();
            this.comboBoxChonTraiCay = new System.Windows.Forms.ComboBox();
            this.comboBoxXuatXu = new System.Windows.Forms.ComboBox();
            this.comboBoxLoai = new System.Windows.Forms.ComboBox();
            this.labelGiaTien = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownSoLuong)).BeginInit();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(148, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(228, 31);
            this.label1.TabIndex = 0;
            this.label1.Text = "Siêu thị VinMart ";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(24, 48);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(69, 13);
            this.label2.TabIndex = 0;
            this.label2.Text = "Chọn trái cây";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(288, 48);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(43, 13);
            this.label3.TabIndex = 0;
            this.label3.Text = "Xuất xứ";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(24, 98);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(27, 13);
            this.label4.TabIndex = 0;
            this.label4.Text = "Loại";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(166, 98);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(49, 13);
            this.label5.TabIndex = 0;
            this.label5.Text = "Số lượng";
            // 
            // label6
            // 
            this.label6.Location = new System.Drawing.Point(346, 96);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(43, 18);
            this.label6.TabIndex = 0;
            this.label6.Text = "Giá tiền";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(24, 152);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(86, 13);
            this.label7.TabIndex = 0;
            this.label7.Text = "Tên khách hàng";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(326, 152);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(29, 13);
            this.label8.TabIndex = 0;
            this.label8.Text = "SĐT";
            // 
            // textBoxTenKH
            // 
            this.textBoxTenKH.Location = new System.Drawing.Point(121, 149);
            this.textBoxTenKH.Name = "textBoxTenKH";
            this.textBoxTenKH.Size = new System.Drawing.Size(199, 20);
            this.textBoxTenKH.TabIndex = 1;
            // 
            // textBoxSDT
            // 
            this.textBoxSDT.Location = new System.Drawing.Point(361, 149);
            this.textBoxSDT.Name = "textBoxSDT";
            this.textBoxSDT.Size = new System.Drawing.Size(143, 20);
            this.textBoxSDT.TabIndex = 1;
            // 
            // buttonChoVaoGio
            // 
            this.buttonChoVaoGio.Location = new System.Drawing.Point(27, 349);
            this.buttonChoVaoGio.Name = "buttonChoVaoGio";
            this.buttonChoVaoGio.Size = new System.Drawing.Size(75, 23);
            this.buttonChoVaoGio.TabIndex = 3;
            this.buttonChoVaoGio.Text = "Cho vào giỏ";
            this.buttonChoVaoGio.UseVisualStyleBackColor = true;
            this.buttonChoVaoGio.Click += new System.EventHandler(this.button1_Click);
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(140, 349);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(75, 23);
            this.button2.TabIndex = 3;
            this.button2.Text = "Trả lại";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // buttonMuaHang
            // 
            this.buttonMuaHang.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonMuaHang.Location = new System.Drawing.Point(291, 210);
            this.buttonMuaHang.Name = "buttonMuaHang";
            this.buttonMuaHang.Size = new System.Drawing.Size(163, 113);
            this.buttonMuaHang.TabIndex = 4;
            this.buttonMuaHang.Text = "Mua hàng";
            this.buttonMuaHang.UseVisualStyleBackColor = true;
            this.buttonMuaHang.Click += new System.EventHandler(this.button3_Click);
            // 
            // numericUpDownSoLuong
            // 
            this.numericUpDownSoLuong.Location = new System.Drawing.Point(224, 96);
            this.numericUpDownSoLuong.Name = "numericUpDownSoLuong";
            this.numericUpDownSoLuong.Size = new System.Drawing.Size(105, 20);
            this.numericUpDownSoLuong.TabIndex = 5;
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.checkBoxChuoi);
            this.groupBox1.Controls.Add(this.checkBoxHong);
            this.groupBox1.Controls.Add(this.checkBoxBuoi);
            this.groupBox1.Controls.Add(this.checkBoxLe);
            this.groupBox1.Controls.Add(this.checkBoxNho);
            this.groupBox1.Controls.Add(this.checkBoxCam);
            this.groupBox1.Location = new System.Drawing.Point(27, 175);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(200, 158);
            this.groupBox1.TabIndex = 7;
            this.groupBox1.TabStop = false;
            // 
            // checkBoxChuoi
            // 
            this.checkBoxChuoi.AutoSize = true;
            this.checkBoxChuoi.Location = new System.Drawing.Point(18, 135);
            this.checkBoxChuoi.Name = "checkBoxChuoi";
            this.checkBoxChuoi.Size = new System.Drawing.Size(53, 17);
            this.checkBoxChuoi.TabIndex = 0;
            this.checkBoxChuoi.Text = "Chuối";
            this.checkBoxChuoi.UseVisualStyleBackColor = true;
            // 
            // checkBoxHong
            // 
            this.checkBoxHong.AutoSize = true;
            this.checkBoxHong.Location = new System.Drawing.Point(18, 112);
            this.checkBoxHong.Name = "checkBoxHong";
            this.checkBoxHong.Size = new System.Drawing.Size(52, 17);
            this.checkBoxHong.TabIndex = 0;
            this.checkBoxHong.Text = "Hồng";
            this.checkBoxHong.UseVisualStyleBackColor = true;
            // 
            // checkBoxBuoi
            // 
            this.checkBoxBuoi.AutoSize = true;
            this.checkBoxBuoi.Location = new System.Drawing.Point(18, 89);
            this.checkBoxBuoi.Name = "checkBoxBuoi";
            this.checkBoxBuoi.Size = new System.Drawing.Size(47, 17);
            this.checkBoxBuoi.TabIndex = 0;
            this.checkBoxBuoi.Text = "Bưởi";
            this.checkBoxBuoi.UseVisualStyleBackColor = true;
            // 
            // checkBoxLe
            // 
            this.checkBoxLe.AutoSize = true;
            this.checkBoxLe.Location = new System.Drawing.Point(18, 66);
            this.checkBoxLe.Name = "checkBoxLe";
            this.checkBoxLe.Size = new System.Drawing.Size(38, 17);
            this.checkBoxLe.TabIndex = 0;
            this.checkBoxLe.Text = "Lê";
            this.checkBoxLe.UseVisualStyleBackColor = true;
            // 
            // checkBoxNho
            // 
            this.checkBoxNho.AutoSize = true;
            this.checkBoxNho.Location = new System.Drawing.Point(18, 43);
            this.checkBoxNho.Name = "checkBoxNho";
            this.checkBoxNho.Size = new System.Drawing.Size(46, 17);
            this.checkBoxNho.TabIndex = 0;
            this.checkBoxNho.Text = "Nho";
            this.checkBoxNho.UseVisualStyleBackColor = true;
            // 
            // checkBoxCam
            // 
            this.checkBoxCam.AutoSize = true;
            this.checkBoxCam.Location = new System.Drawing.Point(18, 20);
            this.checkBoxCam.Name = "checkBoxCam";
            this.checkBoxCam.Size = new System.Drawing.Size(47, 17);
            this.checkBoxCam.TabIndex = 0;
            this.checkBoxCam.Text = "Cam";
            this.checkBoxCam.UseVisualStyleBackColor = true;
            // 
            // comboBoxChonTraiCay
            // 
            this.comboBoxChonTraiCay.FormattingEnabled = true;
            this.comboBoxChonTraiCay.Items.AddRange(new object[] {
            "Cam",
            "Nho",
            "Lê",
            "Bưởi",
            "Hồng",
            "Chuối"});
            this.comboBoxChonTraiCay.Location = new System.Drawing.Point(121, 45);
            this.comboBoxChonTraiCay.Name = "comboBoxChonTraiCay";
            this.comboBoxChonTraiCay.Size = new System.Drawing.Size(121, 21);
            this.comboBoxChonTraiCay.TabIndex = 8;
            this.comboBoxChonTraiCay.SelectedIndexChanged += new System.EventHandler(this.comboBoxChonTraiCay_SelectedIndexChanged);
            // 
            // comboBoxXuatXu
            // 
            this.comboBoxXuatXu.FormattingEnabled = true;
            this.comboBoxXuatXu.Location = new System.Drawing.Point(361, 45);
            this.comboBoxXuatXu.Name = "comboBoxXuatXu";
            this.comboBoxXuatXu.Size = new System.Drawing.Size(121, 21);
            this.comboBoxXuatXu.TabIndex = 8;
            // 
            // comboBoxLoai
            // 
            this.comboBoxLoai.FormattingEnabled = true;
            this.comboBoxLoai.Items.AddRange(new object[] {
            "A"});
            this.comboBoxLoai.Location = new System.Drawing.Point(57, 95);
            this.comboBoxLoai.Name = "comboBoxLoai";
            this.comboBoxLoai.Size = new System.Drawing.Size(103, 21);
            this.comboBoxLoai.TabIndex = 8;
            // 
            // labelGiaTien
            // 
            this.labelGiaTien.Location = new System.Drawing.Point(410, 96);
            this.labelGiaTien.Name = "labelGiaTien";
            this.labelGiaTien.Size = new System.Drawing.Size(83, 18);
            this.labelGiaTien.TabIndex = 0;
            this.labelGiaTien.Text = "...";
            this.labelGiaTien.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // DatHang
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(516, 384);
            this.Controls.Add(this.comboBoxLoai);
            this.Controls.Add(this.comboBoxXuatXu);
            this.Controls.Add(this.comboBoxChonTraiCay);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.numericUpDownSoLuong);
            this.Controls.Add(this.buttonMuaHang);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.buttonChoVaoGio);
            this.Controls.Add(this.textBoxSDT);
            this.Controls.Add(this.textBoxTenKH);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.labelGiaTien);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Name = "DatHang";
            this.Text = "Đặt hàng trái cây";
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownSoLuong)).EndInit();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.TextBox textBoxTenKH;
        private System.Windows.Forms.TextBox textBoxSDT;
        private System.Windows.Forms.Button buttonChoVaoGio;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button buttonMuaHang;
        private System.Windows.Forms.NumericUpDown numericUpDownSoLuong;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.CheckBox checkBoxChuoi;
        private System.Windows.Forms.CheckBox checkBoxHong;
        private System.Windows.Forms.CheckBox checkBoxBuoi;
        private System.Windows.Forms.CheckBox checkBoxLe;
        private System.Windows.Forms.CheckBox checkBoxNho;
        private System.Windows.Forms.CheckBox checkBoxCam;
        private System.Windows.Forms.ComboBox comboBoxChonTraiCay;
        private System.Windows.Forms.ComboBox comboBoxXuatXu;
        private System.Windows.Forms.ComboBox comboBoxLoai;
        private System.Windows.Forms.Label labelGiaTien;
    }
}

